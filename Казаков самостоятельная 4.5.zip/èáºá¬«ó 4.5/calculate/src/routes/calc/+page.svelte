<script>

    import{createEventDispatcher} from 'svelte';
    const dispatch = createEventDispatcher();
    
    let num1 = 0;
    let num2 = 0;
    let action = '+';
    let result = 0;

    function calculate(){
        switch (action){
            case '+':
                result = num1 + num2;
                break;
            case '-':
                result = num1 - num2;
                break;
            case '*':
                result  = num1 * num2;
                break;
            case '/':
                result = num1 / num2;
                break;
        }
        dispatch( 'calculation' ,{result});
    }

</script>

<main>
    <h1>Простой калькулятор</h1>
    
    <input type="number" bind:value={num1} placeholder="Введите первое число">
    <select bind:value={action}>
        <option value="+">+</option>
        <option value="-">-</option>
        <option value="*">*</option>
        <option value="/">/</option>
    </select>
    <input type="number" bind:value={num2} placeholder="Введите второе число">
    <button on:click={calculate}>Посчитать</button>
    <!-- выводить результат, если не ноль -->
    {#if result!==''}
    <p>Результат: {result}</p>
    {/if}
    <hr>
    <div  class="addres">Исаева А.В. 2024</div>
</main>

<style>
    main{
        margin-top: 30px;
        display: flex;
        flex-direction: column;
        align-items: center;
        text-shadow: 2px 2px 5px rgb(52, 3, 3);
        box-shadow: 2px 3px 5px rgba(100, 100, 101),
        -2px -3px 5px rgba(100, 100, 101);
        height: 550px;
        background-color: coral;
        border-radius: 30px;
    }

    input, select, button{
        margin: 10px;
        padding: 5px;
        border: 1px solid #ccc;
        border-radius: 3px;
    }

    button{
        background-color:#4caf50;
        color: White;
        padding: 10px;
    }

    p{
        font-size: 25px;
    }

    hr{
        background-color: black;
        height: 5px;
        width: 50%;
    }

    .addres{
        font: 1rem Mistral;
    }
</style>